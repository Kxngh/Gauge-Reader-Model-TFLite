# redo > 2024-12-13 4:41pm
https://universe.roboflow.com/assignment-codds/redo-hdcjl

Provided by a Roboflow user
License: CC BY 4.0

