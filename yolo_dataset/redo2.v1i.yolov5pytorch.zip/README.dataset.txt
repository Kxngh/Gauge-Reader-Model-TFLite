# redo2 > 2024-12-14 2:03am
https://universe.roboflow.com/assignment-codds/redo2

Provided by a Roboflow user
License: CC BY 4.0

